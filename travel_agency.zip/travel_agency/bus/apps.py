from django.apps import AppConfig


class BusConfig(AppConfig):
    name = 'bus'
